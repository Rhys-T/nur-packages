#!/bin/sh

rm -f configure
autoconf
rm -rf autom4te.cache
